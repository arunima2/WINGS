#!/bin/bash

#input to component/workflow in wings image is named input_file (if changed, change needs to be reflected in resources/adding_inputs.json)
#output of component/workflow in wings image is named output_file (if changed, change needs to be reflected in below in line 15)
###############################################Parameters####################################################################
container_id="a4a564902909" # Get from command - docker ps -a  -q
file_to_upload="data_obs_1.txt" #Change resources/adding_inputs.json with name of input file
name_of_workflow="sc1_wf"
name_of_output_file="output.txt"
#################################################################################################################
python manage_data.py -s http://localhost:8080/wings-portal -dom blank -dt data_m -up $file_to_upload #Uploads the needed file
python run.py -s http://localhost:8080/wings-portal -dom blank -t $name_of_workflow -i resources/adding_inputs.json -a #Runs the workflow with input defined in the JSON file
sleep 5s #Waiting for workflow to finish before checking for output
docker cp $container_id:/opt/wings/storage/default/users/admin/blank/data . #Copying the data folder from the docker container wings image
mv data outputs #changing name of data folder
cd outputs
find ./ -type f \( \! -name 'output_file*' \) -exec rm {} \; #keep only output files, remove all else
for file in output_file*; do mv "$file" "$name_of_output_file"; done #Change name of output file from a random alphanumeric to required filename
cd ..
##################################################################################################################




	